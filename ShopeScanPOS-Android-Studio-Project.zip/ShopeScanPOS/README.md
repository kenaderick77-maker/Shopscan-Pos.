# ShopeScan POS (Android / Kotlin / Jetpack Compose)

Offline-first supermarket/shop POS starter project.

## Included
- Kotlin + Jetpack Compose + Material 3
- Room (SQLite) local persistence for products and sales
- Local checkout flow and transaction history
- Basic product creation, stock deduction and low-stock dashboard count
- WorkManager connectivity-constrained sync worker (sales header sync scaffold)
- Firebase Authentication, Firestore and FCM integration points (backend setup still required)
- Admin/cashier role model and notification service scaffold

## Open in Android Studio
1. Open this folder in Android Studio (Ladybug or newer recommended).
2. Allow Gradle sync.
3. Create a Firebase project and register an Android app using package:
   `com.shopescan.pos`
4. Download `google-services.json` and place it in `app/`.
5. Enable Email/Password Authentication, Cloud Firestore and Firebase Cloud Messaging.
6. Deploy the Firestore rules in `firebase/firestore.rules`.
7. Add a trusted backend (Cloud Functions or your own server) to send FCM notifications after a sale document is created. Never put Firebase Admin credentials in the Android app.
8. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important implementation notes
- The app records normal sales locally without internet.
- The sync worker is a safe integration point; production sync needs a Firebase project and backend endpoint/rules.
- Remote admin notifications require internet and a configured FCM sender on a trusted backend. Offline sales are queued and synchronized later.
- For two phones, provision one Admin and one or more Cashier accounts. Do not allow clients to assign themselves the Admin role.
- Offline sales on multiple devices can temporarily show stale stock. A production deployment should define stock reservation/conflict policy on the server.
- Currency defaults to SSP in the UI and should be configurable before production.
- This is a runnable foundation, not a production-certified accounting system. Test backups, permissions, tax rules, receipt printers and stock reconciliation before live use.

## Suggested first-run setup
Create an Admin user in Firebase Authentication, then assign role `ADMIN` through a trusted admin process / Firestore console. Create cashier users and assign `CASHIER`.

## Current scope / remaining production work
This first project package is a foundation and UI/data-layer prototype. Before using it for real trading, complete and test:
- Admin/cashier sign-in screens and trusted role provisioning.
- Full product, purchase, supplier, expense, customer-credit and reporting workflows.
- Barcode camera integration and receipt printing/sharing.
- Transaction-safe checkout and stock adjustment, including full sale-line cloud sync.
- Secure Cloud Function/server that validates synced sales and sends FCM to Admin devices.
- FCM device-token registration, notification permission prompt, backup/restore and conflict handling.
