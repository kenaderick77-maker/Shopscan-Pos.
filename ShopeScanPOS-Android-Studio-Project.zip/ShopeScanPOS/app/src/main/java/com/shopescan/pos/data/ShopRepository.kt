package com.shopescan.pos.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class ShopRepository(
    private val products: ProductDao,
    private val sales: SaleDao
) {
    fun observeProducts(): Flow<List<Product>> = products.observeAll()
    fun observeSales(): Flow<List<Sale>> = sales.observeSales()
    fun productCount() = products.count()
    fun saleCount() = sales.count()

    suspend fun saveProduct(product: Product) = products.upsert(product)
    suspend fun findBarcode(code: String) = products.findByBarcode(code)

    suspend fun checkout(
        cart: List<CartLine>,
        discount: Double,
        paymentMethod: String,
        cashierName: String
    ): String {
        require(cart.isNotEmpty()) { "Cart is empty" }
        require(discount >= 0) { "Discount cannot be negative" }
        val total = cart.sumOf { it.lineTotal } - discount
        require(total >= 0) { "Discount exceeds subtotal" }
        val saleId = "SS-${System.currentTimeMillis()}-${UUID.randomUUID().toString().take(5)}"
        // Stock checks and sale insertion should be wrapped in a Room transaction in production.
        cart.forEach {
            val changed = products.reduceStock(it.product.id, it.quantity)
            check(changed == 1) { "Insufficient stock for ${it.product.name}" }
        }
        val sale = Sale(
            id = saleId,
            cashierName = cashierName,
            subtotal = cart.sumOf { it.lineTotal },
            discount = discount,
            total = total,
            paymentMethod = paymentMethod
        )
        sales.insertSale(sale)
        sales.insertLines(cart.map {
            SaleLine(
                saleId = saleId,
                productId = it.product.id,
                productName = it.product.name,
                quantity = it.quantity,
                unitPrice = it.product.sellingPrice,
                unitCost = it.product.costPrice
            )
        })
        return saleId
    }
}
