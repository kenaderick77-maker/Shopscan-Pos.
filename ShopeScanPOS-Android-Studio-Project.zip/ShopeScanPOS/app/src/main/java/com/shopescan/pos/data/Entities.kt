package com.shopescan.pos.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val barcode: String = "",
    val category: String = "General",
    val costPrice: Double,
    val sellingPrice: Double,
    val quantity: Int,
    val lowStockLevel: Int = 5,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey val id: String,
    val createdAt: Long = System.currentTimeMillis(),
    val cashierId: String = "local-cashier",
    val cashierName: String = "Cashier",
    val subtotal: Double,
    val discount: Double = 0.0,
    val total: Double,
    val paymentMethod: String,
    val syncState: String = "PENDING"
)

@Entity(tableName = "sale_lines")
data class SaleLine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: String,
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val unitPrice: Double,
    val unitCost: Double
)

data class CartLine(
    val product: Product,
    val quantity: Int
) {
    val lineTotal: Double get() = product.sellingPrice * quantity
}
