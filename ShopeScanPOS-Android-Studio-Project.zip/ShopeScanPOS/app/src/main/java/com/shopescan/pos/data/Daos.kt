package com.shopescan.pos.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name")
    fun observeAll(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun findById(id: Long): Product?

    @Query("SELECT * FROM products WHERE barcode = :barcode LIMIT 1")
    suspend fun findByBarcode(barcode: String): Product?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(product: Product): Long

    @Query("UPDATE products SET quantity = quantity - :qty, updatedAt = :now WHERE id = :productId AND quantity >= :qty")
    suspend fun reduceStock(productId: Long, qty: Int, now: Long = System.currentTimeMillis()): Int

    @Query("UPDATE products SET quantity = quantity + :qty, updatedAt = :now WHERE id = :productId")
    suspend fun addStock(productId: Long, qty: Int, now: Long = System.currentTimeMillis())

    @Delete
    suspend fun delete(product: Product)

    @Query("SELECT COUNT(*) FROM products")
    fun count(): Flow<Int>
}

@Dao
interface SaleDao {
    @Query("SELECT * FROM sales ORDER BY createdAt DESC")
    fun observeSales(): Flow<List<Sale>>

    @Query("SELECT * FROM sale_lines WHERE saleId = :saleId")
    suspend fun linesFor(saleId: String): List<SaleLine>

    @Insert
    suspend fun insertSale(sale: Sale)

    @Insert
    suspend fun insertLines(lines: List<SaleLine>)

    @Query("UPDATE sales SET syncState = 'SYNCED' WHERE id = :saleId")
    suspend fun markSynced(saleId: String)

    @Query("SELECT * FROM sales WHERE syncState = 'PENDING' ORDER BY createdAt")
    suspend fun pendingSales(): List<Sale>

    @Query("SELECT COUNT(*) FROM sales")
    fun count(): Flow<Int>

    @Query("SELECT COALESCE(SUM(total), 0) FROM sales WHERE createdAt >= :start AND createdAt < :end")
    fun salesTotal(start: Long, end: Long): Flow<Double>
}
