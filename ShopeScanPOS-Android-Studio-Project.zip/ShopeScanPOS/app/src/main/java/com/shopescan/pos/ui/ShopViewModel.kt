package com.shopescan.pos.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shopescan.pos.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ShopViewModel(private val repo: ShopRepository) : ViewModel() {
    val products = repo.observeProducts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val sales = repo.observeSales().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun saveProduct(name: String, barcode: String, cost: String, price: String, stock: String) {
        val c = cost.toDoubleOrNull() ?: return
        val p = price.toDoubleOrNull() ?: return
        val q = stock.toIntOrNull() ?: return
        if (name.isBlank() || c < 0 || p < 0 || q < 0) return
        viewModelScope.launch {
            repo.saveProduct(Product(name = name.trim(), barcode = barcode.trim(), costPrice = c, sellingPrice = p, quantity = q))
        }
    }

    fun checkout(cart: List<CartLine>, discount: Double, payment: String, cashier: String, onDone: (String) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            runCatching { repo.checkout(cart, discount, payment, cashier) }
                .onSuccess(onDone).onFailure { onError(it.message ?: "Sale failed") }
        }
    }
}
