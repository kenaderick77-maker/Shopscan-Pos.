package com.shopescan.pos.sync

import android.content.Context
import androidx.work.*
import com.google.firebase.firestore.FirebaseFirestore
import com.shopescan.pos.data.AppDatabase
import kotlinx.coroutines.tasks.await

class SyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            val dao = AppDatabase.get(applicationContext).saleDao()
            val firestore = FirebaseFirestore.getInstance()
            dao.pendingSales().forEach { sale ->
                firestore.collection("sales").document(sale.id).set(
                    mapOf(
                        "saleId" to sale.id,
                        "createdAt" to sale.createdAt,
                        "cashierId" to sale.cashierId,
                        "cashierName" to sale.cashierName,
                        "subtotal" to sale.subtotal,
                        "discount" to sale.discount,
                        "total" to sale.total,
                        "paymentMethod" to sale.paymentMethod,
                        "syncState" to "SYNCED"
                    )
                ).await()
                dao.markSynced(sale.id)
            }
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    companion object {
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<SyncWorker>(15, java.util.concurrent.TimeUnit.MINUTES)
                .setConstraints(
                    Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
                ).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "shopescan_sync", ExistingPeriodicWorkPolicy.KEEP, request
            )
        }
    }
}
