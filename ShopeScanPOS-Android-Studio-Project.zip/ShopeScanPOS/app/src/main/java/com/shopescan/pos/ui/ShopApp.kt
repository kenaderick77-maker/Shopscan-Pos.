package com.shopescan.pos.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.shopescan.pos.data.CartLine
import com.shopescan.pos.data.Product
import java.text.NumberFormat
import java.util.Locale

private fun money(value: Double) = "SSP " + NumberFormat.getNumberInstance(Locale.US).format(value)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopApp(vm: ShopViewModel) {
    var tab by remember { mutableStateOf("Dashboard") }
    var cart by remember { mutableStateOf(listOf<CartLine>()) }
    var message by remember { mutableStateOf("") }
    val products by vm.products.collectAsState()
    val sales by vm.sales.collectAsState()
    Scaffold(
        topBar = { TopAppBar(title = { Text("ShopeScan POS") }, actions = {
            IconButton(onClick = { tab = "Settings" }) { Icon(Icons.Default.Settings, "Settings") }
        }) },
        bottomBar = {
            NavigationBar {
                listOf("Dashboard", "Products", "POS", "Sales").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = { Icon(when(item) {
                            "Dashboard" -> Icons.Default.Dashboard
                            "Products" -> Icons.Default.Inventory
                            "POS" -> Icons.Default.PointOfSale
                            else -> Icons.Default.ReceiptLong
                        }, item) },
                        label = { Text(item) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            when (tab) {
                "Dashboard" -> {
                    Text("Shop overview", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SummaryCard("Products", products.size.toString(), Modifier.weight(1f))
                        SummaryCard("Sales", sales.size.toString(), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    SummaryCard("Low stock items", products.count { it.quantity <= it.lowStockLevel }.toString(), Modifier.fillMaxWidth())
                    Spacer(Modifier.height(16.dp))
                    Text("Recent sales", style = MaterialTheme.typography.titleMedium)
                    sales.take(5).forEach { Text("${it.id} • ${money(it.total)} • ${it.paymentMethod}") }
                }
                "Products" -> ProductScreen(products, vm)
                "POS" -> PosScreen(products, cart, { cart = it }, { msg -> message = msg }, vm)
                "Sales" -> {
                    Text("Sales history", style = MaterialTheme.typography.headlineSmall)
                    LazyColumn { items(sales) { sale ->
                        ListItem(
                            headlineContent = { Text(sale.id) },
                            supportingContent = { Text("${sale.cashierName} • ${sale.paymentMethod} • ${sale.syncState}") },
                            trailingContent = { Text(money(sale.total)) }
                        )
                        HorizontalDivider()
                    } }
                }
                else -> {
                    Text("Settings", style = MaterialTheme.typography.headlineSmall)
                    Text("Currency: SSP (default)")
                    Text("Offline database: Room / SQLite")
                    Text("Cloud sync: configure Firebase to enable multi-phone sync.")
                    Text("User roles: ADMIN and CASHIER (enforce roles in Firebase rules/backend).")
                }
            }
            if (message.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(message, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    ElevatedCard(modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(value, style = MaterialTheme.typography.headlineMedium)
        }
    }
}

@Composable
private fun ProductScreen(products: List<Product>, vm: ShopViewModel) {
    var name by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    Text("Products & inventory", style = MaterialTheme.typography.headlineSmall)
    OutlinedTextField(name, { name = it }, label = { Text("Product name") }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(barcode, { barcode = it }, label = { Text("Barcode (optional)") }, modifier = Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(cost, { cost = it }, label = { Text("Cost price") }, modifier = Modifier.weight(1f))
        OutlinedTextField(price, { price = it }, label = { Text("Selling price") }, modifier = Modifier.weight(1f))
    }
    OutlinedTextField(stock, { stock = it }, label = { Text("Opening stock") }, modifier = Modifier.fillMaxWidth())
    Button(onClick = {
        vm.saveProduct(name, barcode, cost, price, stock)
        name = ""; barcode = ""; cost = ""; price = ""; stock = ""
    }, modifier = Modifier.fillMaxWidth()) { Text("Save product") }
    Spacer(Modifier.height(12.dp))
    LazyColumn {
        items(products) { p ->
            ListItem(
                headlineContent = { Text(p.name) },
                supportingContent = { Text("Stock: ${p.quantity} • Barcode: ${p.barcode.ifBlank { "Not set" }}") },
                trailingContent = { Text(money(p.sellingPrice)) }
            )
            HorizontalDivider()
        }
    }
}

@Composable
private fun PosScreen(
    products: List<Product>,
    cart: List<CartLine>,
    onCart: (List<CartLine>) -> Unit,
    showMessage: (String) -> Unit,
    vm: ShopViewModel
) {
    var search by remember { mutableStateOf("") }
    var payment by remember { mutableStateOf("Cash") }
    val subtotal = cart.sumOf { it.lineTotal }
    Text("Point of sale", style = MaterialTheme.typography.headlineSmall)
    OutlinedTextField(search, { search = it }, label = { Text("Search product or barcode") }, modifier = Modifier.fillMaxWidth())
    LazyColumn(Modifier.weight(1f, fill = false)) {
        items(products.filter { it.name.contains(search, true) || it.barcode.contains(search) }) { p ->
            ListItem(
                headlineContent = { Text(p.name) },
                supportingContent = { Text("Stock ${p.quantity} • ${money(p.sellingPrice)}") },
                trailingContent = {
                    TextButton(onClick = {
                        if (p.quantity < 1) showMessage("Out of stock")
                        else {
                            val existing = cart.find { it.product.id == p.id }
                            onCart(if (existing == null) cart + CartLine(p, 1)
                            else cart.map { if (it.product.id == p.id) it.copy(quantity = it.quantity + 1) else it })
                        }
                    }) { Text("Add") }
                }
            )
        }
    }
    HorizontalDivider()
    Text("Cart (${cart.sumOf { it.quantity }} items)", style = MaterialTheme.typography.titleMedium)
    cart.forEach { line ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${line.product.name} × ${line.quantity}")
            Text(money(line.lineTotal))
        }
    }
    Text("Total: ${money(subtotal)}", style = MaterialTheme.typography.titleLarge)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Cash", "Mobile Money", "Card").forEach { method ->
            FilterChip(selected = payment == method, onClick = { payment = method }, label = { Text(method) })
        }
    }
    Button(
        onClick = {
            vm.checkout(cart, 0.0, payment, "Cashier",
                onDone = { showMessage("Sale recorded: $it"); onCart(emptyList()) },
                onError = { showMessage(it) })
        },
        enabled = cart.isNotEmpty(),
        modifier = Modifier.fillMaxWidth()
    ) { Text("Complete sale") }
}
