package com.shopescan.pos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopescan.pos.data.AppDatabase
import com.shopescan.pos.data.ShopRepository
import com.shopescan.pos.ui.ShopApp
import com.shopescan.pos.ui.ShopViewModel
import com.shopescan.pos.sync.SyncWorker

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        SyncWorker.schedule(this)
        val repository = ShopRepository(db.productDao(), db.saleDao())
        setContent { ShopApp(viewModel { ShopViewModel(repository) }) }
    }
}
